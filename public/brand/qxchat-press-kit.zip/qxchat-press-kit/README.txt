QxChat press kit
https://getqxchat.com/press

logo/         The QxChat icon and logo, as SVG and PNG.
              qxchat-logo-blue: on light backgrounds.
              qxchat-logo-white: on dark or blue backgrounds.
              qxchat-logo-black: for one-colour printing.
screenshots/  Real screenshots of the desktop and Android apps.

Brand blue: #1c71d8
Fonts: SN Pro (text and logo), JetBrains Mono (code). Both under the SIL Open Font License.

Please do not stretch, recolour, rotate or add effects to the logo.
Contact: qxchat@ihorizon.org
